package com.capg.management.service;

import java.util.List;

import com.capg.management.dto.ModuleDto;
import com.capg.management.exception.ManagementException;

public interface IModuleService {
	public List<String> getDetails() throws ManagementException;
	public ModuleDto addModuleScoreinfo(ModuleDto moduleDTO) throws ManagementException;
}
