package com.capg.management.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capg.management.dto.ModuleDto;
import com.capg.management.exception.ManagementException;
import com.capg.management.utility.DbConnection;

public class ModuleDaoImpl implements IModuleDao {
	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;
	
	@Override
	public List<String> getDetails() throws ManagementException {
		// TODO Auto-generated method stub
		List<String> traineeList = new ArrayList<String>();
		try {
			conn = DbConnection.getConnection();
			
				preparedStatement = conn.prepareStatement(IQueryMapper.GETINFOOFTRAINEE);	
				resultSet = preparedStatement.executeQuery();
				while(resultSet.next()){
					traineeList.add(resultSet.getString("trainee_id"));
				}

		} catch (SQLException e) {
			e.printStackTrace();
			throw new ManagementException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new ManagementException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					resultSet.close();
					preparedStatement.close();
					conn.close();
					
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new ManagementException(
						"Couldn't close the connection");
			}
		}
		
		return traineeList;
	}

	@Override
	public boolean addModuleScoreinfo(ModuleDto moduleDTO) throws ManagementException{
		// TODO Auto-generated method stub
		boolean inserted=false;
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.INSERTTRAINEEQUERY);
			preparedStatement.setString(1, moduleDTO.getTraineeId());
			preparedStatement.setString(2, moduleDTO.getModuleName());
			preparedStatement.setInt(3, moduleDTO.getMpt());
			preparedStatement.setInt(4, moduleDTO.getMtt());
			preparedStatement.setInt(5, moduleDTO.getAssignmentMarks());
			preparedStatement.setInt(6, moduleDTO.getTotalMarks());
			preparedStatement.setInt(7, moduleDTO.getGradeNumber());
			inserted= true;
		} catch (SQLException e) {
			
			throw new ManagementException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new ManagementException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					
					preparedStatement.close();
					conn.close();
					
				}
			} catch (Exception e) {
				
				throw new ManagementException(
						"Couldn't close the connection");
			}
		}
		
		 return inserted;
	}

}
