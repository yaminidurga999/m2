/**
 * 
 */
package com.capg.management.service;

import java.util.List;

import com.capg.management.dao.IModuleDao;
import com.capg.management.dao.ModuleDaoImpl;
import com.capg.management.dto.ModuleDto;
import com.capg.management.exception.ManagementException;

/**
 * @author learning
 *
 */
public class ModuleServiceImpl implements IModuleService{

	@Override
	public List<String> getDetails() throws ManagementException {
		// TODO Aut-generated method stub
		IModuleDao moduleDao = new ModuleDaoImpl();
		
		return moduleDao.getDetails();
	}

	@Override
	public ModuleDto addModuleScoreinfo(ModuleDto module)
			throws ManagementException {
		// TODO Auto-generated method stub
		IModuleDao Dao = new ModuleDaoImpl();
		boolean insertFlag = false;
		
		double total=0;
		int grade=0;
		total=(module.getMpt()*0.7+module.getMtt()*0.15+module.getAssignmentMarks()*0.15);
		if(total>=0 && total<50)
			grade=0;
		else
		if(total>=50 && total<60)
			grade=1;
		else
		if(total>=60 && total<70)
			grade=2;
		else		
		if(total>=70 && total<80)
			grade=3;
		else
		if(total>=80 && total<90)
			grade=4;
		else
		if(total>=90 && total<=100)
			grade=5;
		module.setTotalMarks((int)total);
		module.setGradeNumber(grade);
		insertFlag = Dao.addModuleScoreinfo(module);
		return module;
	}

}
