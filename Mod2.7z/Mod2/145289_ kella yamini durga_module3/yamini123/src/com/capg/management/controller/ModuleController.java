package com.capg.management.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capg.management.dto.ModuleDto;
import com.capg.management.exception.ManagementException;
import com.capg.management.service.IModuleService;
import com.capg.management.service.ModuleServiceImpl;

/**
 * Servlet implementation class ModuleController1
 */
@WebServlet("*.obj")
public class ModuleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModuleController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ModuleDto moddto = new ModuleDto();
		String targetAdd = "view/AddAssessment.jsp";
		String targetSuccess = "view/ModuleResult.jsp";
		String target = null;
		String path = request.getServletPath().trim();
	
		RequestDispatcher rd=null;
		 
		IModuleService moduleService=null;
		switch(path){
		case "/AddAssessmentLoad.obj" : 
			 moduleService = new ModuleServiceImpl();
			List<String> traineeList = new ArrayList<String>();
 
			try {
				traineeList = moduleService.getDetails();
				request.setAttribute("traineeList", traineeList);
				System.out.println(traineeList);
			} catch (ManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			target = targetAdd;
 
 
			break;
		case "/AddAssessmentResult Now.obj" :
			 moduleService = new ModuleServiceImpl();
			String traineeId = (String)request.getParameter("traineeId");
			String moduleName = (String)request.getParameter("moduleName");
			String mptScore = (String)request.getParameter("mpt");
			String mttScore = (String)request.getParameter("mtt");
			String assignementScore = (String)request.getParameter("assignement");
			//System.out.println(moduleName);
			
			moddto.setTraineeId(traineeId);
			moddto.setModuleName(moduleName);
			moddto.setMpt(Integer.parseInt(mptScore));
			moddto.setMtt(Integer.parseInt(mttScore));
			moddto.setAssignmentMarks(Integer.parseInt(assignementScore));
 
			try {
				moddto =moduleService.addModuleScoreinfo(moddto);
				request.setAttribute("traineeId",traineeId);
				request.setAttribute("moduleName",moduleName);
				request.setAttribute("total",moddto.getTotalMarks());
				request.setAttribute("grade",moddto.getGradeNumber());
 
				target = targetSuccess;
 
			} catch (ManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		//System.out.println(target);
		RequestDispatcher rd1 = request.getRequestDispatcher(target);
		rd1.forward(request, response);
 
	}
	}


