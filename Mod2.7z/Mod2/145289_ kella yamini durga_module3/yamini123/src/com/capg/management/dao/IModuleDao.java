package com.capg.management.dao;

import java.util.List;

import com.capg.management.dto.ModuleDto;
import com.capg.management.exception.ManagementException;

public interface IModuleDao {
	
public List<String> getDetails() throws ManagementException;
public boolean addModuleScoreinfo(ModuleDto moduleDTO) throws ManagementException;

}
