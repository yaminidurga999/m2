package com.capg.management.dao;

public interface IQueryMapper {
	String GETINFOOFTRAINEE = "SELECT * FROM trainees";
	String INSERTTRAINEEQUERY="INSERT INTO AssessmentScore VALUES(?,?,?,?,?,?,?)";
	
}
