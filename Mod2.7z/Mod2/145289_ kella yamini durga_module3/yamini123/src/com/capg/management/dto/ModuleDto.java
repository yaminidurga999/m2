/**
 * 
 */
package com.capg.management.dto;

/**
 * @author learning
 *
 */
public class ModuleDto {
private String traineeId;
private String moduleName;
private int mpt;
private int mtt;
private int assignmentMarks;
private int totalMarks;
private int gradeNumber;
public String getTraineeId() {
	return traineeId;
}
public void setTraineeId(String traineeId) {
	this.traineeId = traineeId;
}
public String getModuleName() {
	return moduleName;
}
public void setModuleName(String moduleName) {
	this.moduleName = moduleName;
}
public int getMpt() {
	return mpt;
}
public void setMpt(int mpt) {
	this.mpt = mpt;
}
public int getMtt() {
	return mtt;
}
public void setMtt(int mtt) {
	this.mtt = mtt;
}
public int getAssignmentMarks() {
	return assignmentMarks;
}
public void setAssignmentMarks(int assignmentMarks) {
	this.assignmentMarks = assignmentMarks;
}
public int getTotalMarks() {
	return totalMarks;
}
public void setTotalMarks(int totalMarks) {
	this.totalMarks = totalMarks;
}
public int getGradeNumber() {
	return gradeNumber;
}
public void setGradeNumber(int gradeNumber) {
	this.gradeNumber = gradeNumber;
}
@Override
public String toString() {
	return "ModuleDto [traineeId=" + traineeId + ", moduleName=" + moduleName
			+ ", mpt=" + mpt + ", mtt=" + mtt + ", assignmentMarks="
			+ assignmentMarks + ", totalMarks=" + totalMarks + ", gradeNumber="
			+ gradeNumber + "]";
}

}