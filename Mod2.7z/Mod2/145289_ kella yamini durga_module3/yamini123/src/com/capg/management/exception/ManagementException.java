package com.capg.management.exception;

public class ManagementException extends Exception {
public ManagementException(String message){
	super(message);
}
}
